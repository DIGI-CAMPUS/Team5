let loginBtn = document.querySelector(".loginBtn"); //로그인버튼 요소를 가져올거다

loginBtn.addEventListener("click", function () {
  let inputId = document.querySelector(".id").value;
  let inputPw = document.querySelector(".pw").value;
  if (inputId.includes("@") && inputPw.length > 4) {
    document.querySelector(".loginBtn").style.color = "white";
  } else {
    alert("아이디와 암호를 다시 확인 후 입력해 주세요");
    document.querySelector(".loginBtn").style.background = "default";
  }
  return false; //경고창 뜨고 페이지 넘어가지 않게
});
